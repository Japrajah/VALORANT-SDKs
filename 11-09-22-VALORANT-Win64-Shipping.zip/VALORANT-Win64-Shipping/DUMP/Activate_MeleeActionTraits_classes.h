// BlueprintGeneratedClass Activate_MeleeActionTraits.Activate_MeleeActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_MeleeActionTraits_C : UActionTraits {
};

