// BlueprintGeneratedClass AnimNotifyState_OnDeadAndSettled.AnimNotifyState_OnDeadAndSettled_C
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotifyState_OnDeadAndSettled_C : UAnimNotifyState {

	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_OnDeadAndSettled.AnimNotifyState_OnDeadAndSettled_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x32b9180
};

