// BlueprintGeneratedClass BombInteractionBuff.BombInteractionBuff_C
// Size: 0x900 (Inherited: 0x900)
struct UBombInteractionBuff_C : UAresGameplayBuff {
};

