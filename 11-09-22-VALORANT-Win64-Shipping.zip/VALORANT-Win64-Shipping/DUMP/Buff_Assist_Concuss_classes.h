// BlueprintGeneratedClass Buff_Assist_Concuss.Buff_Assist_Concuss_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_Assist_Concuss_C : UAresGameplayBuff {
};

