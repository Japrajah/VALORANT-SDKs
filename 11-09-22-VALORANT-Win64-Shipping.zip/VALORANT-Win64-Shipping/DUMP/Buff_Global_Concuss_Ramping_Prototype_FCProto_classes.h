// BlueprintGeneratedClass Buff_Global_Concuss_Ramping_Prototype_FCProto.Buff_Global_Concuss_Ramping_Prototype_FCProto_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_Global_Concuss_Ramping_Prototype_FCProto_C : UBuff_Global_Concuss_Ramping_Prototype_C {
};

