// UserDefinedEnum CeremonyIdentifier.CeremonyIdentifier
enum class CeremonyIdentifier : uint8 {
	NewEnumerator1 = 0,
	NewEnumerator2 = 1,
	NewEnumerator0 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	NewEnumerator5 = 5,
	NewEnumerator7 = 6,
	CeremonyIdentifier_MAX = 7
};

