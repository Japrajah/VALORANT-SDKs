// UserDefinedStruct CharacterAbilityAffectedTargetInfo.CharacterAbilityAffectedTargetInfo
// Size: 0x0c (Inherited: 0x00)
struct FCharacterAbilityAffectedTargetInfo {
	struct AShooterPlayerState* AffectedPlayer_2_BAF988E34EAAE6B7A1D4758455186559; // 0x00(0x08)
	float Value_5_203891704B7EF064EDB5528BFECC4807; // 0x08(0x04)
};

