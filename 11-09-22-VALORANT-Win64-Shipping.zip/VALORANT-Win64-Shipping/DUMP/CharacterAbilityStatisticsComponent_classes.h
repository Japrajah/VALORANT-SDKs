// BlueprintGeneratedClass CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C
// Size: 0x238 (Inherited: 0x128)
struct UCharacterAbilityStatisticsComponent_C : UGameStatisticsComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x128(0x08)
	struct TArray<struct FCharacterAbilityCastInfo> AuthAbilityCasts; // 0x130(0x10)
	int32_t MostRecentCast; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct TArray<struct FAbilityUsageEvent> TelemetryCastEvents; // 0x148(0x10)
	struct AShooterCharacter* OwningCharacter; // 0x158(0x08)
	struct AAresEquippable* OwningEquippable; // 0x160(0x08)
	struct TMap<enum class ECharacterAbilityStatisticList, struct FText> StatToLocalizedTextMap; // 0x168(0x50)
	float RoundStartTime; // 0x1b8(0x04)
	char pad_1BC[0x4]; // 0x1bc(0x04)
	struct UBaseTeamComponent* TeamComponent; // 0x1c0(0x08)
	bool ReclaimableAbility; // 0x1c8(0x01)
	char pad_1C9[0x7]; // 0x1c9(0x07)
	struct TMap<enum class ECharacterAbilityStatisticList, enum class EAbilityStatisticAccumulationType> StatToAccumulationType; // 0x1d0(0x50)
	bool bAutoTrackDestroyedCount; // 0x220(0x01)
	char pad_221[0x7]; // 0x221(0x07)
	struct TArray<struct FAbilityTelemetryEventPackage> TelemetryUsageEvents; // 0x228(0x10)

	void GetBestCastIndexForReporter(struct AActor* Reporter, int32_t& CastIndex); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.GetBestCastIndexForReporter // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x32b9180
	void Auth Create Telemetry Usage Event with Stats(struct FVector EventLocation, struct TArray<struct FAbilityTelemetryStasticParameters>& Stats, struct AActor* CastLookupActor, int32_t& EventID); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.Auth Create Telemetry Usage Event with Stats // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void Auth Add Effected Player to Telemetry Event(int32_t EventID, enum class ECharacterAbilityStatisticList Statistic, struct AShooterCharacter*& Player, enum class EAresAlliance Alliance); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.Auth Add Effected Player to Telemetry Event // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void ConvertEffectInfosToTelemetryEffectInfos(struct TArray<struct FCharacterAbilityEffectInfo>& InEffectInfo, struct TArray<struct FAbilityEffectInfo>& OutTelemetryEffectInfos); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.ConvertEffectInfosToTelemetryEffectInfos // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthAddTelemetryStatistic(int32_t EventID, enum class ECharacterAbilityStatisticList Stat, enum class EAresAlliance Alliance, float Value, struct AShooterCharacter* AffectedCharacter); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddTelemetryStatistic // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthCreateTelemetryUsageEvent(struct FVector Location, struct AActor* CastLookupActor, int32_t& EventID); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthCreateTelemetryUsageEvent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthCommitTelemetryUsageEvents(); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthCommitTelemetryUsageEvents // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthAddTempTelemetryUsageEvent(enum class ECharacterAbilityStatisticList Statistic, float Value, struct FVector Location, struct AShooterPlayerState* AffectedPlayer, float AffectedPlayerValue); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddTempTelemetryUsageEvent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthIncrementAbilityDestroyedCount(int32_t DestroyedCount, int32_t CastIndex); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthIncrementAbilityDestroyedCount // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AddAbilityStatisticToArray(struct TArray<struct FCharacterAbilityEffectInfo>& InOutEffectArray, enum class ECharacterAbilityStatisticList Stat, enum class EAresAlliance Alliance, float Value, struct AShooterCharacter* AffectedCharacter); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AddAbilityStatisticToArray // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthAddAbilityStatistic_New(enum class ECharacterAbilityStatisticList Stat, enum class EAresAlliance Alliance, float Value, int32_t CastIndex, struct AShooterCharacter* AffectedCharacter); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddAbilityStatistic_New // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	int32_t GetLatestCastIndex(); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.GetLatestCastIndex // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void GetCastTime(float PhaseTime, enum class EAresGamePhase PhaseName, float& CastTime); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.GetCastTime // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x32b9180
	void CreateAbilityEffectInfo(enum class ECharacterAbilityStatisticList Statistic, float AggregateValue, struct AShooterPlayerState* AffectedPlayer, float AffectedPlayerValue, struct FCharacterAbilityEffectInfo& CharacterAbilityEffectInfo); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.CreateAbilityEffectInfo // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void CreateAbilityCastInfo(struct FVector Location, struct FCharacterAbilityCastInfo& CastInfo); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.CreateAbilityCastInfo // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x32b9180
	void AuthAddAbilityStatisticToNewestCast(enum class ECharacterAbilityStatisticList Stat, float Value, struct AShooterCharacter* AffectedCharacter); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddAbilityStatisticToNewestCast // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthAddEffectedPlayerToNewestCast(enum class ECharacterAbilityStatisticList Statistic, struct AShooterCharacter*& Player, enum class EAresAlliance Alliance); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddEffectedPlayerToNewestCast // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthAddEffectedPlayer(int32_t CastIndex, enum class ECharacterAbilityStatisticList Statistic, struct AShooterCharacter*& Player, enum class EAresAlliance Alliance); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddEffectedPlayer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void GetValidCastIndex(int32_t CastIndex, int32_t& ValidIndex); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.GetValidCastIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	int32_t AuthCastAbility(struct FVector AbilityLocation); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthCastAbility // (BlueprintAuthorityOnly|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthAddAbilityStatistic(enum class ECharacterAbilityStatisticList Stat, enum class EAresAlliance Alliance, float Value, int32_t CastIndex, struct AShooterCharacter* AffectedCharacter); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthAddAbilityStatistic // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void ReceiveBeginPlay(); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x32b9180
	void AuthUpdateEffectLocation(int32_t CastIndex, struct FVector Location); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthUpdateEffectLocation // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void OnRoundBegin_Event_1(int32_t RoundNumberBeginning); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.OnRoundBegin_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void OnPhaseChange_Event_1(enum class EAresGamePhase NewPhase); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.OnPhaseChange_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void AuthItemOnSetOwner_Event_1(struct AAresItem* item, struct AActor* PrevOwner, struct AActor* NewOwner); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.AuthItemOnSetOwner_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void OnRoundEnd_Event_1(int32_t RoundNumberEnding); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.OnRoundEnd_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void HandleAbilitySpawnedSubActor(int32_t CastIndex, struct AActor* SubActor); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.HandleAbilitySpawnedSubActor // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void HandleSubActorPreDeath(struct UDamageResponse* Response); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.HandleSubActorPreDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void OnSubActorDestroyed(struct AActor* DestroyedActor); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.OnSubActorDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void ExecuteUbergraph_CharacterAbilityStatisticsComponent(int32_t EntryPoint); // Function CharacterAbilityStatisticsComponent.CharacterAbilityStatisticsComponent_C.ExecuteUbergraph_CharacterAbilityStatisticsComponent // (Final|UbergraphFunction) // @ game+0x32b9180
};

