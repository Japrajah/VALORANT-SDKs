// UserDefinedStruct CharacterImpactParticle.CharacterImpactParticle
// Size: 0x90 (Inherited: 0x00)
struct FCharacterImpactParticle {
	struct FAresHitImpactParticle HeadDamage_11_F5167C1D4CE0C5F4B20FC6B2BB90929E; // 0x00(0x18)
	struct FAresHitImpactParticle BodyDamage_10_9572CBBA482AE6E93B5ECA92894E09C4; // 0x18(0x18)
	struct FAresHitImpactParticle LegDamage_12_88D09BFF4850FB5532FEB28D827C554E; // 0x30(0x18)
	struct FAresHitImpactParticle HeadKill_13_26AE074A4A1BE82534BB3B863D041202; // 0x48(0x18)
	struct FAresHitImpactParticle BodyKill_14_8A72B11A462035F92D80B48C35EA1E4B; // 0x60(0x18)
	struct FAresHitImpactParticle LegKill_15_306362FB40061F5F318FEE83A218D9FA; // 0x78(0x18)
};

