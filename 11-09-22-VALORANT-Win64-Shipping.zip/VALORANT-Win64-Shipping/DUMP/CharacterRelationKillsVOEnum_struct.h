// UserDefinedEnum CharacterRelationKillsVOEnum.CharacterRelationKillsVOEnum
enum class CharacterRelationKillsVOEnum : uint8 {
	NewEnumerator5 = 0,
	NewEnumerator6 = 1,
	CharacterRelationKillsVOEnum_MAX = 2
};

