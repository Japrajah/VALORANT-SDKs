// BlueprintGeneratedClass ClientNavUpActionTraits.ClientNavUpActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UClientNavUpActionTraits_C : UActionTraits {
};

