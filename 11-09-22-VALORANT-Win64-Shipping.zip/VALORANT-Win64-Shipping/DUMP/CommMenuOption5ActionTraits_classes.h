// BlueprintGeneratedClass CommMenuOption5ActionTraits.CommMenuOption5ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCommMenuOption5ActionTraits_C : UActionTraits {
};

