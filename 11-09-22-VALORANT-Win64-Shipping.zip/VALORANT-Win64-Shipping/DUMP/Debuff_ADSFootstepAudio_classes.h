// BlueprintGeneratedClass Debuff_ADSFootstepAudio.Debuff_ADSFootstepAudio_C
// Size: 0x900 (Inherited: 0x900)
struct UDebuff_ADSFootstepAudio_C : UAresGameplayBuff {
};

