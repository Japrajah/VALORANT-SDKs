// BlueprintGeneratedClass Debuff_AutoZipline.Debuff_AutoZipline_C
// Size: 0x900 (Inherited: 0x900)
struct UDebuff_AutoZipline_C : UAresGameplayBuff {
};

