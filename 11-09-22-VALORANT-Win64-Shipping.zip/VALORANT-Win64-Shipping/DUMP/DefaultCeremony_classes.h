// BlueprintGeneratedClass DefaultCeremony.DefaultCeremony_C
// Size: 0x3f0 (Inherited: 0x3f0)
struct ADefaultCeremony_C : ABaseCeremony_C {

	bool ShouldDisplayCeremony(struct FAresCeremonyDecisionContext& DecisionContext); // Function DefaultCeremony.DefaultCeremony_C.ShouldDisplayCeremony // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void UserConstructionScript_1(); // Function DefaultCeremony.DefaultCeremony_C.UserConstructionScript_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
};

