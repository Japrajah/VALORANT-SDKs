// BlueprintGeneratedClass DmgType_SniperRifleBase.DmgType_SniperRifleBase_C
// Size: 0x158 (Inherited: 0x158)
struct UDmgType_SniperRifleBase_C : UDmgType_GunBase_C {
};

