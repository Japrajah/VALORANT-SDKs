// UserDefinedEnum EInputValidated.EInputValidated
enum class EInputValidated : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator2 = 1,
	NewEnumerator1 = 2,
	NewEnumerator0 = 3,
	EInputValidated_MAX = 4
};

