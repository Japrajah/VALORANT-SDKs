// UserDefinedEnum EKillBannerAnimation.EKillBannerAnimation
enum class EKillBannerAnimation : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	EKillBannerAnimation_MAX = 3
};

