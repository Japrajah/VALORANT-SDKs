// BlueprintGeneratedClass EquipLastUsedActionTraits.EquipLastUsedActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UEquipLastUsedActionTraits_C : UActionTraits {
};

