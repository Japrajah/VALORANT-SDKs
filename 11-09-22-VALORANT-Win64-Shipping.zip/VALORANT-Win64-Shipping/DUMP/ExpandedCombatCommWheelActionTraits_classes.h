// BlueprintGeneratedClass ExpandedCombatCommWheelActionTraits.ExpandedCombatCommWheelActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UExpandedCombatCommWheelActionTraits_C : UActionTraits {
};

