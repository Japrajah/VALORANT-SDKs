// BlueprintGeneratedClass FXC_Bomb_Equip.FXC_Bomb_Equip_C
// Size: 0x561 (Inherited: 0x561)
struct AFXC_Bomb_Equip_C : AFXC_Gun_Equip_C {
};

