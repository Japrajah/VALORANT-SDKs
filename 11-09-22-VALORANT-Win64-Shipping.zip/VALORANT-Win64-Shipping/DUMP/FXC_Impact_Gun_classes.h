// BlueprintGeneratedClass FXC_Impact_Gun.FXC_Impact_Gun_C
// Size: 0x668 (Inherited: 0x668)
struct AFXC_Impact_Gun_C : AFXC_Impact_Base_C {
};

