// BlueprintGeneratedClass FXC_Impact_Melee_5.FXC_Impact_Melee_4_C
// Size: 0x610 (Inherited: 0x610)
struct AFXC_Impact_Melee_4_C : AFXC_Impact_Melee_C {
};

