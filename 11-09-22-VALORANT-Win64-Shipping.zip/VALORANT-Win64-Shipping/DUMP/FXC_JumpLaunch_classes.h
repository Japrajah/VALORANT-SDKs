// BlueprintGeneratedClass FXC_JumpLaunch.FXC_JumpLaunch_C
// Size: 0x560 (Inherited: 0x560)
struct AFXC_JumpLaunch_C : AFXC_GroundSound_C {
};

