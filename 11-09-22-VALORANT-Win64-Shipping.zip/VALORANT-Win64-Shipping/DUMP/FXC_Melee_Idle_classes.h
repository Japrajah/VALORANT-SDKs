// BlueprintGeneratedClass FXC_Melee_Idle.FXC_Melee_Idle_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_Melee_Idle_C : AEffectContainer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)

	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function FXC_Melee_Idle.FXC_Melee_Idle_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x32b9180
	void ExecuteUbergraph_FXC_Melee_Idle(int32_t EntryPoint); // Function FXC_Melee_Idle.FXC_Melee_Idle_C.ExecuteUbergraph_FXC_Melee_Idle // (Final|UbergraphFunction) // @ game+0x32b9180
};

