// BlueprintGeneratedClass FXC_RedDot_Close.FXC_RedDot_Close_C
// Size: 0x548 (Inherited: 0x548)
struct AFXC_RedDot_Close_C : AFXC_RedDot_Open_C {
};

