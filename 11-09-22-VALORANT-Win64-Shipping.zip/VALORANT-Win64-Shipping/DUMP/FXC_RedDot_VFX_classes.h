// BlueprintGeneratedClass FXC_RedDot_VFX.FXC_RedDot_VFX_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_RedDot_VFX_C : AEffectContainer {
	struct UReflex_Particle_Component_C* GunSkin_Reflex_Particle_Component; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

