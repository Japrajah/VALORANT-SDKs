// BlueprintGeneratedClass ForceModule_Tag_WallPen.ForceModule_Tag_WallPen_C
// Size: 0x214 (Inherited: 0x214)
struct UForceModule_Tag_WallPen_C : UForceModule_TagBase_C {
};

