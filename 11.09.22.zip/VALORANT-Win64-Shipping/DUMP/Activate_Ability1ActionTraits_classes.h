// BlueprintGeneratedClass Activate_Ability1ActionTraits.Activate_Ability1ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_Ability1ActionTraits_C : UActionTraits {
};

