// BlueprintGeneratedClass Activate_UltimateActionTraits.Activate_UltimateActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_UltimateActionTraits_C : UActionTraits {
};

