// UserDefinedEnum Aud_RTPC_Registry.Aud_RTPC_Registry
enum class Aud_RTPC_Registry : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	Aud_RTPC_MAX = 3
};

