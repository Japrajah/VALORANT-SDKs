// BlueprintGeneratedClass BPAresClientGameInstance.BPAresClientGameInstance_C
// Size: 0x578 (Inherited: 0x578)
struct UBPAresClientGameInstance_C : UAresClientGameInstance {
};

