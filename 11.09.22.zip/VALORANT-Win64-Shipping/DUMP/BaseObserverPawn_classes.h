// BlueprintGeneratedClass BaseObserverPawn.BaseObserverPawn_C
// Size: 0x480 (Inherited: 0x480)
struct ABaseObserverPawn_C : AObserverPawn {
};

