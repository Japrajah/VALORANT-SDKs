// BlueprintGeneratedClass BaseShooterCamera.BaseShooterCamera_C
// Size: 0x2f00 (Inherited: 0x2f00)
struct ABaseShooterCamera_C : AShooterCamera {
};

