// BlueprintGeneratedClass BombPlayerState.BombPlayerState_C
// Size: 0xa58 (Inherited: 0xa50)
struct ABombPlayerState_C : ABasePlayerState_C {
	struct UBombTeamComponent* BombTeam; // 0xa50(0x08)
};

