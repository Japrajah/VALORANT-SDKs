// UserDefinedEnum BombSiteEnum.BombSiteEnum
enum class BombSiteEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	BombSiteEnum_MAX = 3
};

