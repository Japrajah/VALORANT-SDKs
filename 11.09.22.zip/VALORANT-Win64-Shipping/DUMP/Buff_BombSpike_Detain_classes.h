// BlueprintGeneratedClass Buff_BombSpike_Detain.Buff_BombSpike_Detain_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_BombSpike_Detain_C : UAresGameplayBuff {
};

