// BlueprintGeneratedClass CanPickupBombBuff.CanPickupBombBuff_C
// Size: 0x900 (Inherited: 0x900)
struct UCanPickupBombBuff_C : UAresGameplayBuff {
};

