// BlueprintGeneratedClass ClientNavDownActionTraits.ClientNavDownActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UClientNavDownActionTraits_C : UActionTraits {
};

