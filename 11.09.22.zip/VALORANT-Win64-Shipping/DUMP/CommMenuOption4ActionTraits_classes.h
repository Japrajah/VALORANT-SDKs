// BlueprintGeneratedClass CommMenuOption4ActionTraits.CommMenuOption4ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCommMenuOption4ActionTraits_C : UActionTraits {
};

