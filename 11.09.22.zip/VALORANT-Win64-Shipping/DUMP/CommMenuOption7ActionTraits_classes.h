// BlueprintGeneratedClass CommMenuOption7ActionTraits.CommMenuOption7ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCommMenuOption7ActionTraits_C : UActionTraits {
};

