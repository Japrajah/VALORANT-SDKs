// UserDefinedStruct EEmoteSetup.EEmoteSetup
// Size: 0x0c (Inherited: 0x00)
struct FEEmoteSetup {
	struct AEffectContainer* FXC_2_70992BD34CF405E140D5CB840FD2C2F1; // 0x00(0x08)
	float ThirdPersonDuration_5_752AA8A744CFD96F13A585846A130BEA; // 0x08(0x04)
};

