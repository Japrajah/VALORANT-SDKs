// BlueprintGeneratedClass EnemyUtilityPing.EnemyUtilityPing_C
// Size: 0x6b8 (Inherited: 0x6b8)
struct AEnemyUtilityPing_C : ABasePing_C {
};

