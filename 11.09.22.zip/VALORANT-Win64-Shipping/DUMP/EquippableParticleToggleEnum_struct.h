// UserDefinedEnum EquippableParticleToggleEnum.EquippableParticleToggleEnum
enum class EquippableParticleToggleEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EquippableParticleToggleEnum_MAX = 2
};

