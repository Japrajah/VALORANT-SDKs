// BlueprintGeneratedClass FXC_Ascender_MoveDown.FXC_Ascender_MoveDown_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_Ascender_MoveDown_C : AEffectContainer {
	struct UComp_FXC_AudioLoop_C* Comp_FXC_AudioLoop; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

