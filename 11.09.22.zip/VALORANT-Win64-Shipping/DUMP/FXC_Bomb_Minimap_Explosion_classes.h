// BlueprintGeneratedClass FXC_Bomb_Minimap_Explosion.FXC_Bomb_Minimap_Explosion_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_Bomb_Minimap_Explosion_C : AEffectContainer {
	struct UBaseMinimapComponent_AlwaysVisible_C* BaseMinimapComponent_AlwaysVisible; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

