// BlueprintGeneratedClass FXC_Bomb_Plant_Enemy.FXC_Bomb_Plant_Enemy_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_Bomb_Plant_Enemy_C : AEffectContainer {
	struct UComp_FXC_Audio_Team_C* Comp_FXC_Audio_Enemy; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

