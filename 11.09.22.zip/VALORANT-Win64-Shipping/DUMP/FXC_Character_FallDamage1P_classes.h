// BlueprintGeneratedClass FXC_Character_FallDamage1P.FXC_Character_FallDamage1P_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_Character_FallDamage1P_C : AEffectContainer {
	struct UComp_FXC_AudioBasic_C* Comp_FXC_AudioBasic; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

