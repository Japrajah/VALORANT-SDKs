// BlueprintGeneratedClass FXC_Danger.FXC_Danger_C
// Size: 0x548 (Inherited: 0x530)
struct AFXC_Danger_C : AEffectContainer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct UComp_FXC_HUD_C* Comp_FXC_HUD; // 0x538(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x540(0x08)

	void AdjustLayoutForDevice(); // Function FXC_Danger.FXC_Danger_C.AdjustLayoutForDevice // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x32b9180
	void ReceiveBeginPlay(); // Function FXC_Danger.FXC_Danger_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x32b9180
	void ExecuteUbergraph_FXC_Danger(int32_t EntryPoint); // Function FXC_Danger.FXC_Danger_C.ExecuteUbergraph_FXC_Danger // (Final|UbergraphFunction) // @ game+0x32b9180
};

