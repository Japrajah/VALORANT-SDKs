// BlueprintGeneratedClass FXC_Global_CannotBeUsedInBuyPhase.FXC_Global_CannotBeUsedInBuyPhase_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_Global_CannotBeUsedInBuyPhase_C : AEffectContainer {
	struct UComp_FXC_HUD_WarningMessage_C* Comp_FXC_HUD_WarningMessage; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

