// BlueprintGeneratedClass FXC_Impact_Melee_4.FXC_Impact_Melee_3_C
// Size: 0x610 (Inherited: 0x610)
struct AFXC_Impact_Melee_3_C : AFXC_Impact_Melee_C {
};

