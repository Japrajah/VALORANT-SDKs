// BlueprintGeneratedClass FXC_Impact_Melee_Alt.FXC_Impact_Melee_Alt_C
// Size: 0x610 (Inherited: 0x610)
struct AFXC_Impact_Melee_Alt_C : AFXC_Impact_Melee_C {
};

