// BlueprintGeneratedClass FXC_JumpLand.FXC_JumpLand_C
// Size: 0x560 (Inherited: 0x560)
struct AFXC_JumpLand_C : AFXC_GroundSound_C {
};

