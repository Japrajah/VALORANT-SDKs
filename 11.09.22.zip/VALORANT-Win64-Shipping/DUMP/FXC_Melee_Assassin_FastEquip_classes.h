// BlueprintGeneratedClass FXC_Melee_Assassin_FastEquip.FXC_Melee_Assassin_FastEquip_C
// Size: 0x558 (Inherited: 0x548)
struct AFXC_Melee_Assassin_FastEquip_C : AFXC_Melee_Equip_C {
	struct UComp_FXC_AudioBasic_C* Comp_FXC_AudioBasic; // 0x548(0x08)
	struct UComp_FXC_PlayAnimation_ShooterCharacter_C* Core_Melee_S0_FastEquip_Animation; // 0x550(0x08)
};

