// BlueprintGeneratedClass FXC_Melee_Tactical_Attack_4.FXC_Melee_Tactical_Attack_3_C
// Size: 0x580 (Inherited: 0x570)
struct AFXC_Melee_Tactical_Attack_3_C : AFXC_Melee_Tactical_Attack_2_C {
	struct UAnimMontage* 3PAnim; // 0x570(0x08)
	struct UAnimMontage* 1PAnim; // 0x578(0x08)
};

