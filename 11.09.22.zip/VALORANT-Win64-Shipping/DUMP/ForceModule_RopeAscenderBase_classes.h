// BlueprintGeneratedClass ForceModule_RopeAscenderBase.ForceModule_RopeAscenderBase_C
// Size: 0x178 (Inherited: 0x168)
struct UForceModule_RopeAscenderBase_C : UForceModule {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x168(0x08)
	struct ABP_RopeAscender_C* Ascender; // 0x170(0x08)

	void Initialize(); // Function ForceModule_RopeAscenderBase.ForceModule_RopeAscenderBase_C.Initialize // (Event|Protected|BlueprintEvent) // @ game+0x32b9180
	void ExecuteUbergraph_ForceModule_RopeAscenderBase(int32_t EntryPoint); // Function ForceModule_RopeAscenderBase.ForceModule_RopeAscenderBase_C.ExecuteUbergraph_ForceModule_RopeAscenderBase // (Final|UbergraphFunction) // @ game+0x32b9180
};

