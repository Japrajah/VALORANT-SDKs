// BlueprintGeneratedClass ForceModule_Tag_Heavy.ForceModule_Tag_Heavy_C
// Size: 0x214 (Inherited: 0x214)
struct UForceModule_Tag_Heavy_C : UForceModule_TagBase_C {
};

