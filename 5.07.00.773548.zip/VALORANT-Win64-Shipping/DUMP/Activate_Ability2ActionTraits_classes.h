// BlueprintGeneratedClass Activate_Ability2ActionTraits.Activate_Ability2ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_Ability2ActionTraits_C : UActionTraits {
};

