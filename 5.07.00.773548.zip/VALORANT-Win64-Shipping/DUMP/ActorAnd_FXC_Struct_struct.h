// UserDefinedStruct ActorAnd_FXC_Struct.ActorAnd_FXC_Struct
// Size: 0x28 (Inherited: 0x00)
struct FActorAnd_FXC_Struct {
	struct AActor* Actor_4_B6DEFC46446D77855C7548AA764A57F5; // 0x00(0x08)
	struct FEffectID FXC_ID_6_0AC8DEBF49E741C128663CBA3638673D; // 0x08(0x20)
};

