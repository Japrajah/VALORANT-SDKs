// UserDefinedEnum AfterFiringWhileZoomedOption.AfterFiringWhileZoomedOption
enum class AfterFiringWhileZoomedOption : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	AfterFiringWhileZoomedOption_MAX = 2
};

