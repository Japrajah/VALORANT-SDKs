// BlueprintGeneratedClass AllChatActionTraits.AllChatActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UAllChatActionTraits_C : UActionTraits {
};

