// UserDefinedEnum Aud_StatusEffectsList.Aud_StatusEffectsList
enum class Aud_StatusEffectsList : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	Aud_MAX = 3
};

