// Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Size: 0x30 (Inherited: 0x30)
struct UAutomationUtilsBlueprintLibrary : UBlueprintFunctionLibrary {

	void TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride); // Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2305fc0
};

