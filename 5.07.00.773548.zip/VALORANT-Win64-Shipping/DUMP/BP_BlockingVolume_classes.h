// BlueprintGeneratedClass BP_BlockingVolume.BP_BlockingVolume_C
// Size: 0x3e0 (Inherited: 0x3d0)
struct ABP_BlockingVolume_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct UStaticMeshComponent* Cube; // 0x3d8(0x08)

	void ReceiveBeginPlay(); // Function BP_BlockingVolume.BP_BlockingVolume_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3511cd0
	void ExecuteUbergraph_BP_BlockingVolume(int32_t EntryPoint); // Function BP_BlockingVolume.BP_BlockingVolume_C.ExecuteUbergraph_BP_BlockingVolume // (Final|UbergraphFunction) // @ game+0x3511cd0
};

