// BlueprintGeneratedClass BaseMapPrimaryAsset.BaseMapPrimaryAsset_C
// Size: 0xc1 (Inherited: 0xc0)
struct UBaseMapPrimaryAsset_C : UMapDataAsset {
	enum class MapID MapID; // 0xc0(0x01)
};

