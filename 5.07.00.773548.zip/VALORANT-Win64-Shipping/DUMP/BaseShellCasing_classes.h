// BlueprintGeneratedClass BaseShellCasing.BaseShellCasing_C
// Size: 0x568 (Inherited: 0x568)
struct ABaseShellCasing_C : ABaseEjectable_C {
};

