// BlueprintGeneratedClass BombInteractionBlockEquipping.BombInteractionBlockEquipping_C
// Size: 0x900 (Inherited: 0x900)
struct UBombInteractionBlockEquipping_C : UAresGameplayBuff {
};

