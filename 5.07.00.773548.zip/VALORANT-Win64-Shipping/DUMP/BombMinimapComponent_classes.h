// BlueprintGeneratedClass BombMinimapComponent.BombMinimapComponent_C
// Size: 0x598 (Inherited: 0x580)
struct UBombMinimapComponent_C : UBombMinimapComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x580(0x08)
	struct FLinearColor Enemy Tint; // 0x588(0x10)

	void ReceiveBeginPlay(); // Function BombMinimapComponent.BombMinimapComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3511cd0
	void CustomEvent_1(); // Function BombMinimapComponent.BombMinimapComponent_C.CustomEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x3511cd0
	void CustomEvent_2(); // Function BombMinimapComponent.BombMinimapComponent_C.CustomEvent_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x3511cd0
	void CustomEvent_3(enum class EAresPlayerViewTargetMode NewPlayerViewTargetMode); // Function BombMinimapComponent.BombMinimapComponent_C.CustomEvent_3 // (BlueprintCallable|BlueprintEvent) // @ game+0x3511cd0
	void ExecuteUbergraph_BombMinimapComponent(int32_t EntryPoint); // Function BombMinimapComponent.BombMinimapComponent_C.ExecuteUbergraph_BombMinimapComponent // (Final|UbergraphFunction) // @ game+0x3511cd0
};

