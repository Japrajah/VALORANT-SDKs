// BlueprintGeneratedClass BombPlayerState.BombPlayerState_C
// Size: 0xa60 (Inherited: 0xa58)
struct ABombPlayerState_C : ABasePlayerState_C {
	struct UBombTeamComponent* BombTeam; // 0xa58(0x08)
};

