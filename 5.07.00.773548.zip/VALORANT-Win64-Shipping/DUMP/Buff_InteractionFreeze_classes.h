// BlueprintGeneratedClass Buff_InteractionFreeze.Buff_InteractionFreeze_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_InteractionFreeze_C : UAresGameplayBuff {
};

