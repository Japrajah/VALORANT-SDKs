// BlueprintGeneratedClass Buff_PreventFiring.Buff_PreventFiring_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_PreventFiring_C : UAresGameplayBuff {
};

