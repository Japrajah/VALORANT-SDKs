// BlueprintGeneratedClass Buff_Warmup_Spawn.Buff_Warmup_Spawn_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_Warmup_Spawn_C : UAresGameplayBuff {
};

