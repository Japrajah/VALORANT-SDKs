// UserDefinedEnum CharacterConvoVOEnum.CharacterConvoVOEnum
enum class CharacterConvoVOEnum : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator5 = 1,
	NewEnumerator6 = 2,
	CharacterConvoVOEnum_MAX = 3
};

