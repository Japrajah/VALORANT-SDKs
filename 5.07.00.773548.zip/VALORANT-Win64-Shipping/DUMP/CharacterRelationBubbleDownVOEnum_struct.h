// UserDefinedEnum CharacterRelationBubbleDownVOEnum.CharacterRelationBubbleDownVOEnum
enum class CharacterRelationBubbleDownVOEnum : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator5 = 1,
	NewEnumerator6 = 2,
	CharacterRelationBubbleDownVOEnum_MAX = 3
};

