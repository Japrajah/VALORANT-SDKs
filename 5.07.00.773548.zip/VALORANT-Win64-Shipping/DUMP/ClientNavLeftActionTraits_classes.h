// BlueprintGeneratedClass ClientNavLeftActionTraits.ClientNavLeftActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UClientNavLeftActionTraits_C : UActionTraits {
};

