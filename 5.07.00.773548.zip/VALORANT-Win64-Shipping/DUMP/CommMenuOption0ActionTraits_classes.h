// BlueprintGeneratedClass CommMenuOption0ActionTraits.CommMenuOption0ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCommMenuOption0ActionTraits_C : UActionTraits {
};

