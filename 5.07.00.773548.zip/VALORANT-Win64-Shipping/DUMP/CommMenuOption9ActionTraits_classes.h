// BlueprintGeneratedClass CommMenuOption9ActionTraits.CommMenuOption9ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCommMenuOption9ActionTraits_C : UActionTraits {
};

