// BlueprintGeneratedClass Comp_FXC_SwapMaterials_1P_Overlay.Comp_FXC_SwapMaterials_1P_Overlay_C
// Size: 0x183 (Inherited: 0x183)
struct UComp_FXC_SwapMaterials_1P_Overlay_C : UComp_FXC_SwapMaterials_C {

	void GetSkeletalMeshToSwap(struct AShooterCharacter* ShooterCharacter, struct USkeletalMeshComponent*& Mesh); // Function Comp_FXC_SwapMaterials_1P_Overlay.Comp_FXC_SwapMaterials_1P_Overlay_C.GetSkeletalMeshToSwap // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3511cd0
};

