// BlueprintGeneratedClass Comp_WidgetPool.Comp_WidgetPool_C
// Size: 0x138 (Inherited: 0x138)
struct UComp_WidgetPool_C : UWidgetPoolComponent {
};

