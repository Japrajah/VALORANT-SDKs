// BlueprintGeneratedClass DebugShooterCharacterAnimInstanceHud.DebugShooterCharacterAnimInstanceHud_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UDebugShooterCharacterAnimInstanceHud_C : UDebugShooterCharacterAnimInstanceHudElement {
};

