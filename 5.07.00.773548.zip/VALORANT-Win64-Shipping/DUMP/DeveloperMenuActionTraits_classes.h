// BlueprintGeneratedClass DeveloperMenuActionTraits.DeveloperMenuActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UDeveloperMenuActionTraits_C : UActionTraits {
};

