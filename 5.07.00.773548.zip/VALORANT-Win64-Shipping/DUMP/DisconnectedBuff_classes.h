// BlueprintGeneratedClass DisconnectedBuff.DisconnectedBuff_C
// Size: 0x900 (Inherited: 0x900)
struct UDisconnectedBuff_C : UAresGameplayBuff {
};

