// BlueprintGeneratedClass DmgType_HeavyMachineGunBase.DmgType_HeavyMachineGunBase_C
// Size: 0x158 (Inherited: 0x158)
struct UDmgType_HeavyMachineGunBase_C : UDmgType_GunBase_C {
};

