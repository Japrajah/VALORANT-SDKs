// BlueprintGeneratedClass DmgType_LeverSniperRifle.DmgType_LeverSniperRifle_C
// Size: 0x158 (Inherited: 0x158)
struct UDmgType_LeverSniperRifle_C : UDmgType_SniperRifleBase_C {
};

