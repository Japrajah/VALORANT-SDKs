// BlueprintGeneratedClass DmgType_ObjectiveBombPlantExplosion.DmgType_ObjectiveBombPlantExplosion_C
// Size: 0x14f (Inherited: 0x14f)
struct UDmgType_ObjectiveBombPlantExplosion_C : UDmgType_Base_C {
};

