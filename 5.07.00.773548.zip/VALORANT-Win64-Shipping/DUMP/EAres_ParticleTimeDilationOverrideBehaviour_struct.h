// UserDefinedEnum EAres_ParticleTimeDilationOverrideBehaviour.EAres_ParticleTimeDilationOverrideBehaviour
enum class EAres_ParticleTimeDilationOverrideBehaviour : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EAres_MAX = 2
};

