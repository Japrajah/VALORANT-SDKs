// UserDefinedEnum EPlantedBombState.EPlantedBombState
enum class EPlantedBombState : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EPlantedBombState_MAX = 2
};

