// AnimBlueprintGeneratedClass EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph.EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph_C
// Size: 0x410 (Inherited: 0x300)
struct UEQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x308(0x38)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x340(0x50)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x390(0x80)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph.EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3511cd0
	void ExecuteUbergraph_EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph(int32_t EntryPoint); // Function EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph.EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph_C.ExecuteUbergraph_EQTP_Bomb_S0_Skelmesh_Skeleton_AnimGraph // (Final|UbergraphFunction) // @ game+0x3511cd0
};

