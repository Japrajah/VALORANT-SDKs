// BlueprintGeneratedClass EnemyHerePing.EnemyHerePing_C
// Size: 0x6b8 (Inherited: 0x6b8)
struct AEnemyHerePing_C : ABasePing_C {
};

