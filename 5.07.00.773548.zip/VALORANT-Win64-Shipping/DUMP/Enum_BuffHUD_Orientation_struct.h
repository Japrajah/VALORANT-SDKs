// UserDefinedEnum Enum_BuffHUD_Orientation.Enum_BuffHUD_Orientation
enum class Enum_BuffHUD_Orientation : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	Enum_BuffHUD_MAX = 2
};

