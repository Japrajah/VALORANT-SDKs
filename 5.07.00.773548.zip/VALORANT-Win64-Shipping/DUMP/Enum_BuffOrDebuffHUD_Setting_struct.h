// UserDefinedEnum Enum_BuffOrDebuffHUD_Setting.Enum_BuffOrDebuffHUD_Setting
enum class Enum_BuffOrDebuffHUD_Setting : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	Enum_BuffOrDebuffHUD_MAX = 3
};

