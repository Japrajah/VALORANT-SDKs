// BlueprintGeneratedClass FXC_DEBUG_FogOfWar_Reveal.FXC_DEBUG_FogOfWar_Reveal_C
// Size: 0x608 (Inherited: 0x5f9)
struct AFXC_DEBUG_FogOfWar_Reveal_C : AFXC_Global_Reveal_HiddenWhenVisible_C {
	char pad_5F9[0x7]; // 0x5f9(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x600(0x08)

	void ReceiveTick(float DeltaSeconds); // Function FXC_DEBUG_FogOfWar_Reveal.FXC_DEBUG_FogOfWar_Reveal_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x3511cd0
	void ExecuteUbergraph_FXC_DEBUG_FogOfWar_Reveal(int32_t EntryPoint); // Function FXC_DEBUG_FogOfWar_Reveal.FXC_DEBUG_FogOfWar_Reveal_C.ExecuteUbergraph_FXC_DEBUG_FogOfWar_Reveal // (Final|UbergraphFunction) // @ game+0x3511cd0
};

