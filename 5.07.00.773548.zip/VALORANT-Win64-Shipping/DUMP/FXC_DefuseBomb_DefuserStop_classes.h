// BlueprintGeneratedClass FXC_DefuseBomb_DefuserStop.FXC_DefuseBomb_DefuserStop_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_DefuseBomb_DefuserStop_C : AEffectContainer {
	struct UComp_FXC_PlayAnimation_ShooterCharacter_C* Comp_FXC_PlayAnimation_ShooterCharacter; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

