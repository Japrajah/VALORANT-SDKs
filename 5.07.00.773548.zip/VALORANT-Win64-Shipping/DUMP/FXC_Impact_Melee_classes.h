// BlueprintGeneratedClass FXC_Impact_Melee.FXC_Impact_Melee_C
// Size: 0x610 (Inherited: 0x610)
struct AFXC_Impact_Melee_C : AFXC_ImpactMelee_Base_C {
};

