// BlueprintGeneratedClass FXC_StealthReveal.FXC_StealthReveal_C
// Size: 0x540 (Inherited: 0x530)
struct AFXC_StealthReveal_C : AEffectContainer {
	struct UComp_FXC_AudioBasic_C* Comp_FXC_AudioBasic; // 0x530(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x538(0x08)
};

