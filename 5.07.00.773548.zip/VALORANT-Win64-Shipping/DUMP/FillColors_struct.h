// UserDefinedEnum FillColors.FillColors
enum class FillColors : uint8 {
	NewEnumerator0 = 0,
	FillColors_MAX = 1
};

