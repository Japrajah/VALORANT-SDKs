// BlueprintGeneratedClass Activate_GrenadeAbilityActionTraits.Activate_GrenadeAbilityActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_GrenadeAbilityActionTraits_C : UActionTraits {
};

