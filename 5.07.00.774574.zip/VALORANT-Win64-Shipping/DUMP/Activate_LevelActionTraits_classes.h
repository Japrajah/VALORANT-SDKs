// BlueprintGeneratedClass Activate_LevelActionTraits.Activate_LevelActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_LevelActionTraits_C : UActionTraits {
};

