// BlueprintGeneratedClass Activate_SecondaryActionTraits.Activate_SecondaryActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UActivate_SecondaryActionTraits_C : UActionTraits {
};

