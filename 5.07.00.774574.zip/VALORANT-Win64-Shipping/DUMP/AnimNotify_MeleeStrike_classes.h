// BlueprintGeneratedClass AnimNotify_MeleeStrike.AnimNotify_MeleeStrike_C
// Size: 0x40 (Inherited: 0x40)
struct UAnimNotify_MeleeStrike_C : UAnimNotify {
};

