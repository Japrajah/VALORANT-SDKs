// BlueprintGeneratedClass ArmMovementAnimNotify.ArmMovementAnimNotify_C
// Size: 0x4d (Inherited: 0x40)
struct UArmMovementAnimNotify_C : UAnimNotify {
	struct FName EventName; // 0x40(0x0c)
	enum class ArmMovementType MovementType; // 0x4c(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ArmMovementAnimNotify.ArmMovementAnimNotify_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3511160
};

