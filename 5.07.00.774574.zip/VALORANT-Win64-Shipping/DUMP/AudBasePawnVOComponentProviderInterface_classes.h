// BlueprintGeneratedClass AudBasePawnVOComponentProviderInterface.AudBasePawnVOComponentProviderInterface_C
// Size: 0x30 (Inherited: 0x30)
struct UAudBasePawnVOComponentProviderInterface_C : UInterface {

	void GetAudBasePawnVOComponent(struct UAudBasePawnVOComponent_C*& Component); // Function AudBasePawnVOComponentProviderInterface.AudBasePawnVOComponentProviderInterface_C.GetAudBasePawnVOComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3511160
};

