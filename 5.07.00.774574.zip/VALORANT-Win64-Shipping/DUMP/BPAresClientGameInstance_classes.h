// BlueprintGeneratedClass BPAresClientGameInstance.BPAresClientGameInstance_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UBPAresClientGameInstance_C : UAresClientGameInstance {
};

