// BlueprintGeneratedClass BPAresServerGameInstance.BPAresServerGameInstance_C
// Size: 0x50 (Inherited: 0x50)
struct UBPAresServerGameInstance_C : UAresServerGameInstance {
};

