// BlueprintGeneratedClass BPAresSettingsManager.BPAresSettingsManager_C
// Size: 0x438 (Inherited: 0x438)
struct UBPAresSettingsManager_C : UAresSettingsManager {
};

