// BlueprintGeneratedClass BaseCharacterPrimaryDataAsset.BaseCharacterPrimaryDataAsset_C
// Size: 0x199 (Inherited: 0x198)
struct UBaseCharacterPrimaryDataAsset_C : UCharacterDataAsset {
	enum class CharacterID CharacterID; // 0x198(0x01)
};

