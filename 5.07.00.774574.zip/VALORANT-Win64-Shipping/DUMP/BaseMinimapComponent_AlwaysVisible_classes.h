// BlueprintGeneratedClass BaseMinimapComponent_AlwaysVisible.BaseMinimapComponent_AlwaysVisible_C
// Size: 0x670 (Inherited: 0x663)
struct UBaseMinimapComponent_AlwaysVisible_C : UBaseMinimapComponent_Parent_C {
	char pad_663[0x5]; // 0x663(0x05)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x668(0x08)

	bool ShouldBeVisible(); // Function BaseMinimapComponent_AlwaysVisible.BaseMinimapComponent_AlwaysVisible_C.ShouldBeVisible // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3511160
	void ReceiveBeginPlay(); // Function BaseMinimapComponent_AlwaysVisible.BaseMinimapComponent_AlwaysVisible_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3511160
	void ExecuteUbergraph_BaseMinimapComponent_AlwaysVisible(int32_t EntryPoint); // Function BaseMinimapComponent_AlwaysVisible.BaseMinimapComponent_AlwaysVisible_C.ExecuteUbergraph_BaseMinimapComponent_AlwaysVisible // (Final|UbergraphFunction) // @ game+0x3511160
};

