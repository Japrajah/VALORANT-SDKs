// BlueprintGeneratedClass BaseObserverPlayerState.BaseObserverPlayerState_C
// Size: 0x6e0 (Inherited: 0x6d8)
struct ABaseObserverPlayerState_C : AObserverPlayerState {
	struct USceneComponent* DefaultSceneRoot; // 0x6d8(0x08)

	void PopulateParticipantMatchResults(struct FParticipantMatchResults& OutParticpantMatchResults); // Function BaseObserverPlayerState.BaseObserverPlayerState_C.PopulateParticipantMatchResults // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3511160
	bool ShouldPopulateParticipantMatchResults(); // Function BaseObserverPlayerState.BaseObserverPlayerState_C.ShouldPopulateParticipantMatchResults // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3511160
};

