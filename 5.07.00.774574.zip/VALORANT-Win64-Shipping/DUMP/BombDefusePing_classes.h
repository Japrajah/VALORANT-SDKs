// BlueprintGeneratedClass BombDefusePing.BombDefusePing_C
// Size: 0x6b8 (Inherited: 0x6b8)
struct ABombDefusePing_C : ABasePing_C {
};

