// BlueprintGeneratedClass BombPlantPing.BombPlantPing_C
// Size: 0x6b8 (Inherited: 0x6b8)
struct ABombPlantPing_C : ABasePing_C {
};

