// BlueprintGeneratedClass Buff_Downed_DeathResist.Buff_Downed_DeathResist_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_Downed_DeathResist_C : UAresGameplayBuff {
};

