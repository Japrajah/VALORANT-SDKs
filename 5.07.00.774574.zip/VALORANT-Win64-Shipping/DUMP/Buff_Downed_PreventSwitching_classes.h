// BlueprintGeneratedClass Buff_Downed_PreventSwitching.Buff_Downed_PreventSwitching_C
// Size: 0x900 (Inherited: 0x900)
struct UBuff_Downed_PreventSwitching_C : UAresGameplayBuff {
};

