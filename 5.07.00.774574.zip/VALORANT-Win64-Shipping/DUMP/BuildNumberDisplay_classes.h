// WidgetBlueprintGeneratedClass BuildNumberDisplay.BuildNumberDisplay_C
// Size: 0x2d8 (Inherited: 0x2c8)
struct UBuildNumberDisplay_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UTextBlock* BuildNumber; // 0x2d0(0x08)

	void Construct(); // Function BuildNumberDisplay.BuildNumberDisplay_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3511160
	void PreConstruct(bool IsDesignTime); // Function BuildNumberDisplay.BuildNumberDisplay_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3511160
	void ExecuteUbergraph_BuildNumberDisplay(int32_t EntryPoint); // Function BuildNumberDisplay.BuildNumberDisplay_C.ExecuteUbergraph_BuildNumberDisplay // (Final|UbergraphFunction|HasDefaults) // @ game+0x3511160
};

