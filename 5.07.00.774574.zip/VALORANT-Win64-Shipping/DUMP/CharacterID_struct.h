// UserDefinedEnum CharacterID.CharacterID
enum class CharacterID : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator4 = 5,
	NewEnumerator5 = 6,
	NewEnumerator6 = 7,
	NewEnumerator9 = 8,
	NewEnumerator7 = 9,
	NewEnumerator10 = 10,
	NewEnumerator11 = 11,
	NewEnumerator12 = 12,
	NewEnumerator13 = 13,
	NewEnumerator14 = 14,
	NewEnumerator15 = 15,
	NewEnumerator16 = 16,
	NewEnumerator17 = 17,
	NewEnumerator18 = 18,
	NewEnumerator19 = 19,
	NewEnumerator20 = 20,
	CharacterID_MAX = 21
};

