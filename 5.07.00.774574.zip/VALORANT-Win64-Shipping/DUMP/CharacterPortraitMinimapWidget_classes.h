// WidgetBlueprintGeneratedClass CharacterPortraitMinimapWidget.CharacterPortraitMinimapWidget_C
// Size: 0x300 (Inherited: 0x2f0)
struct UCharacterPortraitMinimapWidget_C : UShooterCharacterMinimapWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f0(0x08)
	struct UImage* BombIcon; // 0x2f8(0x08)

	void ReceiveSetState(); // Function CharacterPortraitMinimapWidget.CharacterPortraitMinimapWidget_C.ReceiveSetState // (Event|Public|BlueprintEvent) // @ game+0x3511160
	void ExecuteUbergraph_CharacterPortraitMinimapWidget(int32_t EntryPoint); // Function CharacterPortraitMinimapWidget.CharacterPortraitMinimapWidget_C.ExecuteUbergraph_CharacterPortraitMinimapWidget // (Final|UbergraphFunction) // @ game+0x3511160
};

