// BlueprintGeneratedClass CharacterSelectActionTraits.CharacterSelectActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCharacterSelectActionTraits_C : UActionTraits {
};

