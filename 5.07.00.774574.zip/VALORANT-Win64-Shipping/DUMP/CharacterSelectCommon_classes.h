// BlueprintGeneratedClass CharacterSelectCommon.CharacterSelectCommon_C
// Size: 0x30 (Inherited: 0x30)
struct UCharacterSelectCommon_C : UBlueprintFunctionLibrary {

	void UpdateImageOnImageWidget(struct UImage* Target Image Widget, struct UObject* Image To Set, struct UObject* __WorldContext); // Function CharacterSelectCommon.CharacterSelectCommon_C.UpdateImageOnImageWidget // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3511160
};

