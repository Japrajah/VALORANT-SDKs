// BlueprintGeneratedClass CommMenuOption3ActionTraits.CommMenuOption3ActionTraits_C
// Size: 0x50 (Inherited: 0x50)
struct UCommMenuOption3ActionTraits_C : UActionTraits {
};

