// BlueprintGeneratedClass Debuff_GrievousWounds.Debuff_GrievousWounds_C
// Size: 0x900 (Inherited: 0x900)
struct UDebuff_GrievousWounds_C : UAresGameplayBuff {
};

