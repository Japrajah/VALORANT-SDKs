// BlueprintGeneratedClass Debuff_RopeAscender.Debuff_RopeAscender_C
// Size: 0x900 (Inherited: 0x900)
struct UDebuff_RopeAscender_C : UAresGameplayBuff {
};

