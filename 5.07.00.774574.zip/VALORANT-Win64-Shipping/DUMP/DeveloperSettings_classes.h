// Class DeveloperSettings.DeveloperSettings
// Size: 0x48 (Inherited: 0x30)
struct UDeveloperSettings : UObject {
	char pad_30[0x18]; // 0x30(0x18)
};

