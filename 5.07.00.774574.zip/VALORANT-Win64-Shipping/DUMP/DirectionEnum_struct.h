// UserDefinedEnum DirectionEnum.DirectionEnum
enum class DirectionEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	DirectionEnum_MAX = 4
};

