// BlueprintGeneratedClass DmgType_FallDamage.DmgType_FallDamage_C
// Size: 0x14f (Inherited: 0x14f)
struct UDmgType_FallDamage_C : UDmgType_Base_C {
};

