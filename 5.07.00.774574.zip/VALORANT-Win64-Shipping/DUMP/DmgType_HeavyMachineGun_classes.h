// BlueprintGeneratedClass DmgType_HeavyMachineGun.DmgType_HeavyMachineGun_C
// Size: 0x158 (Inherited: 0x158)
struct UDmgType_HeavyMachineGun_C : UDmgType_HeavyMachineGunBase_C {
};

