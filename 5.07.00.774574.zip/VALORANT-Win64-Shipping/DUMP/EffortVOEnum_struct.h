// UserDefinedEnum EffortVOEnum.EffortVOEnum
enum class EffortVOEnum : uint8 {
	NewEnumerator11 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator7 = 7,
	NewEnumerator8 = 8,
	NewEnumerator9 = 9,
	NewEnumerator10 = 10,
	EffortVOEnum_MAX = 11
};

