// UserDefinedEnum EmoteVOEnum.EmoteVOEnum
enum class EmoteVOEnum : uint8 {
	NewEnumerator10 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator6 = 5,
	NewEnumerator7 = 6,
	NewEnumerator8 = 7,
	EmoteVOEnum_MAX = 8
};

