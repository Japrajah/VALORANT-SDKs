// Class EsportsEvents.EsportsGameDataEventReceiver
// Size: 0x150 (Inherited: 0x30)
struct UEsportsGameDataEventReceiver : UBaseGameDataEventReceiver {
	char pad_30[0x110]; // 0x30(0x110)
	struct UGameDataExporter* GameDataExporter; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
};

