// BlueprintGeneratedClass FXC_Bomb_Equip.FXC_Bomb_Equip_C
// Size: 0x570 (Inherited: 0x570)
struct AFXC_Bomb_Equip_C : AFXC_Gun_Equip_C {
};

