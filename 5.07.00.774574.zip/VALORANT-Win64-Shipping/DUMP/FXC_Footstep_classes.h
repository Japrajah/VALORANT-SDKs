// BlueprintGeneratedClass FXC_Footstep.FXC_Footstep_C
// Size: 0x570 (Inherited: 0x568)
struct AFXC_Footstep_C : AFXC_GroundSound_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x568(0x08)

	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function FXC_Footstep.FXC_Footstep_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x3511160
	void ExecuteUbergraph_FXC_Footstep(int32_t EntryPoint); // Function FXC_Footstep.FXC_Footstep_C.ExecuteUbergraph_FXC_Footstep // (Final|UbergraphFunction) // @ game+0x3511160
};

