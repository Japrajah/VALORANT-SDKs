// BlueprintGeneratedClass FXC_Gun_BombDefused.FXC_Gun_BombDefused_C
// Size: 0x538 (Inherited: 0x530)
struct AFXC_Gun_BombDefused_C : AEffectContainer {
	struct USceneComponent* DefaultSceneRoot; // 0x530(0x08)
};

