// BlueprintGeneratedClass FXC_Gun_CycleZoom.FXC_Gun_CycleZoom_C
// Size: 0x548 (Inherited: 0x530)
struct AFXC_Gun_CycleZoom_C : AEffectContainer {
	struct UComp_FXC_PlayAnimation_Gun_CycleZoom_C* Comp_FXC_PlayAnimation_Gun_CycleZoom; // 0x530(0x08)
	struct UComp_FXC_PlayAnimation_ShooterCharacter_Gun_CycleZoom_C* Comp_FXC_PlayAnimation_ShooterCharacter_Gun_CycleZoom; // 0x538(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x540(0x08)
};

