// BlueprintGeneratedClass FXC_Impact_Gun_Reentry.FXC_Impact_Gun_Reentry_C
// Size: 0x668 (Inherited: 0x668)
struct AFXC_Impact_Gun_Reentry_C : AFXC_Impact_Base_C {
};

