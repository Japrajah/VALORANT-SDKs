// BlueprintGeneratedClass FXC_Melee_Tactical_Attack_5.FXC_Melee_Tactical_Attack_4_C
// Size: 0x590 (Inherited: 0x580)
struct AFXC_Melee_Tactical_Attack_4_C : AFXC_Melee_Tactical_Attack_3_C {
	struct UAnimMontage* 3PAnim_1; // 0x580(0x08)
	struct UAnimMontage* 1PAnim_1; // 0x588(0x08)
};

