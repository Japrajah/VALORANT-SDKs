// BlueprintGeneratedClass FXC_Melee_Tactical_Inspect.FXC_Melee_Tactical_Inspect_C
// Size: 0x572 (Inherited: 0x572)
struct AFXC_Melee_Tactical_Inspect_C : AFXC_Gun_Emote_C {
};

