// BlueprintGeneratedClass FXC_RedDot_Open.FXC_RedDot_Open_C
// Size: 0x548 (Inherited: 0x548)
struct AFXC_RedDot_Open_C : AFXC_Reflex_Base_C {
};

